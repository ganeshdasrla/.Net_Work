﻿using System;

namespace What_are_the_differences_between_Events_and_Delegates
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
