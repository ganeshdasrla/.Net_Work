﻿using System;

namespace What_are_Access_Specifiers_What_is_the_default_access_modifier_in_a_class
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }

    
   
}
