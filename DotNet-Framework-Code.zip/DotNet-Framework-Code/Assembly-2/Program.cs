﻿namespace Assembly_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();

            employee.GetSalary();
        }
    }
}