﻿namespace Filters_MVC
{
    public class LogActionFilter
    {
    }
}
